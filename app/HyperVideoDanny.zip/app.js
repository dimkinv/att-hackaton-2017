function button_click() {
	alert('when this button is clicked, the app will mirror itself');
}


